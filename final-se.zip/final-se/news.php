<?php
ob_start();
require_once 'db_connect.php';
session_start();

// Log function for debugging
function logError($message) {
    file_put_contents('debug.log', date('Y-m-d H:i:s') . " - News Error: $message\n", FILE_APPEND);
}

// Check for remember_me cookie
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_me'])) {
    try {
        $token = $_COOKIE['remember_me'];
        $stmt = $pdo->prepare("SELECT id, full_name, email, remember_token, remember_token_expiry FROM users WHERE remember_token IS NOT NULL AND remember_token_expiry > NOW()");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $user = null;
        foreach ($users as $u) {
            if (password_verify($token, $u['remember_token'])) {
                $user = $u;
                break;
            }
        }

        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];

            // Load cart from database
            $stmt = $pdo->prepare("SELECT product_id, quantity FROM cart_items WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            $_SESSION['cart'] = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $_SESSION['cart'][$row['product_id']] = $row['quantity'];
            }

            // Load favorites from database
            $stmt = $pdo->prepare("SELECT product_id FROM favorites WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            $_SESSION['favorites'] = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $_SESSION['favorites'][] = $row['product_id'];
            }

            $newExpiry = date('Y-m-d H:i:s', strtotime('+30 days'));
            $stmt = $pdo->prepare("UPDATE users SET remember_token_expiry = ? WHERE id = ?");
            $stmt->execute([$newExpiry, $user['id']]);
            setcookie('remember_me', $token, time() + 30 * 24 * 60 * 60, '/', '', false, true);
            logError("Auto-login via Remember Me: User ID {$user['id']}");
        } else {
            setcookie('remember_me', '', time() - 3600, '/');
            logError("Invalid Remember Me token: $token");
        }
    } catch (PDOException $e) {
        logError("Remember Me DB Error: " . $e->getMessage());
    }
}

// Fetch news articles
$per_page = 6;
$page = isset($_GET['page']) ? max(1, filter_input(INPUT_GET, 'page', FILTER_VALIDATE_INT)) : 1;
$offset = ($page - 1) * $per_page;

try {
    $stmt = $pdo->prepare("SELECT id, title, excerpt, image, author, created_at FROM news ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
    $stmt->bindParam(':limit', $per_page, PDO::PARAM_INT);
    $stmt->bindParam(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $news_articles = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->query("SELECT COUNT(*) FROM news");
    $total_articles = $stmt->fetchColumn();
    $total_pages = ceil($total_articles / $per_page);
} catch (PDOException $e) {
    logError("News DB Error: " . $e->getMessage());
    $_SESSION['errors'] = ["Lỗi cơ sở dữ liệu khi tải tin tức. Vui lòng thử lại."];
    $news_articles = [];
    $total_pages = 1;
}

// Calculate cart and favorite counts for badges
$cart_count = isset($_SESSION['cart']) && !empty($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
$favorite_count = isset($_SESSION['favorites']) && !empty($_SESSION['favorites']) ? count(array_unique($_SESSION['favorites'])) : 0;
?>
    <!DOCTYPE html>
    <html lang="vi">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Tin tức - KidsToyLand</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
        <style>
            :root {
                --primary-color: #FF6B6B;
                --secondary-color: #4ECDC4;
                --accent-color: #FFE66D;
                --text-color: #2D3748;
                --light-color: #F7FFF7;
                --dark-color: #1A202C;
            }

            body {
                font-family: 'Nunito', sans-serif;
                color: var(--text-color);
            }

            /* Header Styles */
            .navbar-brand {
                font-weight: 800;
                font-size: 1.8rem;
            }

            .navbar-brand span {
                color: var(--primary-color);
            }

            .nav-link {
                font-weight: 600;
                color: var(--text-color) !important;
                transition: all 0.3s ease;
            }

            .nav-link:hover {
                color: var(--primary-color) !important;
            }

            .nav-link.active {
                color: var(--primary-color) !important;
            }

            .search-form {
                position: relative;
            }

            .search-form .form-control {
                border-radius: 50px;
                padding-right: 40px;
            }

            .search-form .btn {
                position: absolute;
                right: 5px;
                top: 5px;
                border-radius: 50%;
                width: 30px;
                height: 30px;
                padding: 0;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .btn-primary {
                background-color: var(--primary-color);
                border-color: var(--primary-color);
            }

            .btn-primary:hover {
                background-color: #ff5252;
                border-color: #ff5252;
            }

            /* News Section */
            .news-card {
                border: none;
                border-radius: 15px;
                overflow: hidden;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
                transition: all 0.3s ease;
            }

            .news-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.1);
            }

            .news-card img {
                width: 100%;
                height: 200px;
                object-fit: cover;
            }

            .news-card .card-body {
                padding: 1.5rem;
            }

            .news-card .card-title {
                font-weight: 700;
                font-size: 1.25rem;
                margin-bottom: 0.75rem;
            }

            .news-card .card-text {
                color: #6B7280;
                margin-bottom: 1rem;
            }

            .news-meta {
                font-size: 0.9rem;
                color: #9CA3AF;
            }

            .news-meta i {
                margin-right: 5px;
            }

            /* Pagination */
            .pagination .page-link {
                color: var(--primary-color);
                border: none;
                margin: 0 5px;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .pagination .page-link:hover {
                background-color: var(--primary-color);
                color: white;
            }

            .pagination .page-item.active .page-link {
                background-color: var(--primary-color);
                color: white;
            }

            /* Footer */
            .footer {
                background-color: var(--dark-color);
                color: #fff;
            }

            .footer h5 {
                color: var(--accent-color);
                font-weight: 700;
                margin-bottom: 1.5rem;
            }

            .footer-links {
                list-style: none;
                padding-left: 0;
            }

            .footer-links li {
                margin-bottom: 10px;
            }

            .footer-links a {
                color: #fff;
                text-decoration: none;
                transition: all 0.3s ease;
            }

            .footer-links a:hover {
                color: var(--accent-color);
                padding-left: 5px;
            }

            .social-icons {
                margin-top: 20px;
            }

            .social-icons a {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background-color: rgba(255, 255, 255, 0.1);
                color: #fff;
                margin-right: 10px;
                transition: all 0.3s ease;
            }

            .social-icons a:hover {
                background-color: var(--primary-color);
                transform: translateY(-3px);
            }

            .copyright {
                background-color: rgba(0, 0, 0, 0.2);
            }
        </style>
    </head>
    <body>
    <!-- HEADER -->
    <header>
        <!-- Top Bar -->
        <div class="bg-dark text-white py-2">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <small>
                            <i class="fas fa-phone-alt me-2"></i> Hotline: 1900 1234
                            <i class="fas fa-envelope ms-3 me-2"></i> Email: info@kidstoy.vn
                        </small>
                    </div>
                    <div class="col-md-6 text-end">
                        <small>
                            <a href="#" class="text-white me-3"><i class="fas fa-truck me-1"></i> Theo dõi đơn hàng</a>
                            <a href="#" class="text-white me-3"><i class="fas fa-map-marker-alt me-1"></i> Cửa hàng gần bạn</a>
                            <?php if (isset($_SESSION['user_id'])): ?>
                                <span class="text-white me-3">Xin chào, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                                <a href="logout.php" class="text-white"><i class="fas fa-sign-out-alt me-1"></i> Đăng xuất</a>
                            <?php else: ?>
                                <a href="login.php" class="text-white"><i class="fas fa-user me-1"></i> Đăng nhập</a>
                                <a href="register.php" class="text-white ms-3"><i class="fas fa-user-plus me-1"></i> Đăng ký</a>
                            <?php endif; ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Navigation -->
        <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="index.php">Kids<span>ToyLand</span></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.php">Trang chủ</a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                Sản phẩm
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="#">Đồ chơi cho bé trai</a></li>
                                <li><a class="dropdown-item" href="#">Đồ chơi cho bé gái</a></li>
                                <li><a class="dropdown-item" href="#">Đồ chơi học tập</a></li>
                                <li><a class="dropdown-item" href="#">Đồ chơi vận động</a></li>
                                <li><a class="dropdown-item" href="#">Đồ chơi xếp hình</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Khuyến mãi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="news.php">Tin tức</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php">Về chúng tôi</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#footer">Liên hệ</a>
                        </li>
                    </ul>
                    <div class="d-flex align-items-center">
                        <form class="search-form me-3" action="search.php" method="GET">
                            <input class="form-control" type="search" name="query" placeholder="Tìm kiếm đồ chơi..." aria-label="Search">
                            <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                        </form>
                        <a href="favorites.php" class="btn btn-outline-dark position-relative me-2">
                            <i class="fas fa-heart"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger favorite-badge">
                        <?php echo $favorite_count; ?>
                    </span>
                        </a>
                        <a href="cart.php" class="btn btn-outline-dark position-relative">
                            <i class="fas fa-shopping-cart"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger cart-badge">
                        <?php echo $cart_count; ?>
                    </span>
                        </a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <!-- MAIN CONTENT -->
    <main>
        <!-- News Section -->
        <section class="py-5">
            <div class="container">
                <div class="text-center mb-5">
                    <h2 class="fw-bold">Tin tức mới nhất</h2>
                    <p class="text-muted">Cập nhật các thông tin, mẹo vặt và khuyến mãi từ KidsToyLand</p>
                </div>
                <?php if (isset($_SESSION['errors'])): ?>
                    <div class="alert alert-danger">
                        <?php foreach ($_SESSION['errors'] as $error): ?>
                            <p><?php echo htmlspecialchars($error); ?></p>
                        <?php endforeach; ?>
                        <?php unset($_SESSION['errors']); ?>
                    </div>
                <?php endif; ?>
                <?php if (empty($news_articles)): ?>
                    <p class="text-center">Hiện tại không có tin tức nào.</p>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($news_articles as $article): ?>
                            <div class="col-md-6 col-lg-4">
                                <div class="card news-card h-100">
                                    <?php if ($article['image']): ?>
                                        <img src="<?php echo htmlspecialchars($article['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($article['title']); ?>">
                                    <?php endif; ?>
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo htmlspecialchars($article['title']); ?></h5>
                                        <p class="card-text"><?php echo htmlspecialchars($article['excerpt']); ?></p>
                                        <div class="news-meta">
                                            <span><i class="fas fa-user"></i> <?php echo htmlspecialchars($article['author']); ?></span>
                                            <span class="ms-3"><i class="fas fa-calendar-alt"></i> <?php echo date('d/m/Y', strtotime($article['created_at'])); ?></span>
                                        </div>
                                        <a href="article.php?id=<?php echo $article['id']; ?>" class="btn btn-primary mt-3">Đọc thêm</a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="News pagination" class="mt-5">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page - 1; ?>" aria-label="Previous">
                                        <i class="fas fa-chevron-left"></i>
                                    </a>
                                </li>
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="?page=<?php echo $page + 1; ?>" aria-label="Next">
                                        <i class="fas fa-chevron-right"></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer id="footer" class="footer bg-dark">
        <div class="container">
            <div class="row pt-5">
                <div class="col-md-4 col-12 mb-4">
                    <h5>KidsToyLand</h5>
                    <p>Địa chỉ: 123 Đường Vui Chơi, Quận 1, TP. Hồ Chí Minh</p>
                    <p>Email: info@kidstoy.vn</p>
                    <p>Điện thoại: 1900 1234</p>
                </div>
                <div class="col-md-4 col-12 mb-4">
                    <h5>Liên kết nhanh</h5>
                    <ul class="footer-links">
                        <li><a href="index.php">Trang chủ</a></li>
                        <li><a href="#">Sản phẩm</a></li>
                        <li><a href="#">Khuyến mãi</a></li>
                        <li><a href="news.php">Tin tức</a></li>
                        <li><a href="about.php">Về chúng tôi</a></li>
                        <li><a href="#">Liên hệ</a></li>
                    </ul>
                </div>
                <div class="col-md-4 col-12 mb-4">
                    <h5>Liên hệ</h5>
                    <p>Email: support@kidstoyland.com</p>
                    <p>Hotline: 0123 456 789</p>
                    <div class="social-icons">
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                    </div>
                </div>
            </div>
            <div class="copyright text-center">
                <p>© 2025 KidsToyLand. Tất cả quyền được bảo lưu.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
<?php
ob_end_flush();
?>