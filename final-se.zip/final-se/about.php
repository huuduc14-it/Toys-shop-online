<?php
ob_start();
require_once 'db_connect.php';
session_start();

// Log function for debugging
function logError($message) {
    file_put_contents('debug.log', date('Y-m-d H:i:s') . " - About Error: $message\n", FILE_APPEND);
}

// Check for remember_me cookie
if (!isset($_SESSION['user_id']) && isset($_COOKIE['remember_me'])) {
    try {
        $token = $_COOKIE['remember_me'];
        $stmt = $pdo->prepare("SELECT id, full_name, email, remember_token, remember_token_expiry FROM users WHERE remember_token IS NOT NULL AND remember_token_expiry > NOW()");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $user = null;
        foreach ($users as $u) {
            if (password_verify($token, $u['remember_token'])) {
                $user = $u;
                break;
            }
        }

        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_email'] = $user['email'];

            // Load cart from database
            $stmt = $pdo->prepare("SELECT product_id, quantity FROM cart_items WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            $_SESSION['cart'] = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $_SESSION['cart'][$row['product_id']] = $row['quantity'];
            }

            // Load favorites from database
            $stmt = $pdo->prepare("SELECT product_id FROM favorites WHERE user_id = ?");
            $stmt->execute([$user['id']]);
            $_SESSION['favorites'] = [];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $_SESSION['favorites'][] = $row['product_id'];
            }

            $newExpiry = date('Y-m-d H:i:s', strtotime('+30 days'));
            $stmt = $pdo->prepare("UPDATE users SET remember_token_expiry = ? WHERE id = ?");
            $stmt->execute([$newExpiry, $user['id']]);
            setcookie('remember_me', $token, time() + 30 * 24 * 60 * 60, '/', '', false, true);
            logError("Auto-login via Remember Me: User ID {$user['id']}");
        } else {
            setcookie('remember_me', '', time() - 3600, '/');
            logError("Invalid Remember Me token: $token");
        }
    } catch (PDOException $e) {
        logError("Remember Me DB Error: " . $e->getMessage());
    }
}

// Calculate cart and favorite counts for badges
$cart_count = isset($_SESSION['cart']) && !empty($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0;
$favorite_count = isset($_SESSION['favorites']) && !empty($_SESSION['favorites']) ? count(array_unique($_SESSION['favorites'])) : 0;
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Về chúng tôi - KidsToyLand</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #FF6B6B;
            --secondary-color: #4ECDC4;
            --accent-color: #FFE66D;
            --text-color: #2D3748;
            --light-color: #F7FFF7;
            --dark-color: #1A202C;
        }

        body {
            font-family: 'Nunito', sans-serif;
            color: var(--text-color);
        }

        /* Header Styles */
        .navbar-brand {
            font-weight: 800;
            font-size: 1.8rem;
        }

        .navbar-brand span {
            color: var(--primary-color);
        }

        .nav-link {
            font-weight: 600;
            color: var(--text-color) !important;
            transition: all 0.3s ease;
        }

        .nav-link:hover {
            color: var(--primary-color) !important;
        }

        .nav-link.active {
            color: var(--primary-color) !important;
        }

        .search-form {
            position: relative;
        }

        .search-form .form-control {
            border-radius: 50px;
            padding-right: 40px;
        }

        .search-form .btn {
            position: absolute;
            right: 5px;
            top: 5px;
            border-radius: 50%;
            width: 30px;
            height: 30px;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #ff5252;
            border-color: #ff5252;
        }

        /* About Section */
        .about-hero {
            background: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url('/api/placeholder/1200/400') no-repeat center center;
            background-size: cover;
            padding: 80px 0;
            color: #fff;
            text-align: center;
        }

        .about-hero h1 {
            font-size: 2.5rem;
            font-weight: 800;
        }

        .team-card {
            border: none;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            text-align: center;
        }

        .team-card img {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }

        .team-card .card-body {
            padding: 1.5rem;
        }

        .team-card .card-title {
            font-weight: 700;
            font-size: 1.25rem;
        }

        .team-card .card-text {
            color: #6B7280;
        }

        .contact-info {
            background-color: #f8f9fa;
            padding: 2rem;
            border-radius: 15px;
        }

        .contact-info i {
            color: var(--primary-color);
            margin-right: 10px;
        }

        /* Footer */
        .footer {
            background-color: var(--dark-color);
            color: #fff;
        }

        .footer h5 {
            color: var(--accent-color);
            font-weight: 700;
            margin-bottom: 1.5rem;
        }

        .footer-links {
            list-style: none;
            padding-left: 0;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: #fff;
            text-decoration: none;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--accent-color);
            padding-left: 5px;
        }

        .social-icons {
            margin-top: 20px;
        }

        .social-icons a {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: rgba(255, 255, 255, 0.1);
            color: #fff;
            margin-right: 10px;
            transition: all 0.3s ease;
        }

        .social-icons a:hover {
            background-color: var(--primary-color);
            transform: translateY(-3px);
        }

        .copyright {
            background-color: rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
<!-- HEADER -->
<header>
    <!-- Top Bar -->
    <div class="bg-dark text-white py-2">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <small>
                        <i class="fas fa-phone-alt me-2"></i> Hotline: 1900 1234
                        <i class="fas fa-envelope ms-3 me-2"></i> Email: info@kidstoy.vn
                    </small>
                </div>
                <div class="col-md-6 text-end">
                    <small>
                        <a href="#" class="text-white me-3"><i class="fas fa-truck me-1"></i> Theo dõi đơn hàng</a>
                        <a href="#" class="text-white me-3"><i class="fas fa-map-marker-alt me-1"></i> Cửa hàng gần bạn</a>
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <span class="text-white me-3">Xin chào, <?php echo htmlspecialchars($_SESSION['user_name']); ?></span>
                            <a href="logout.php" class="text-white"><i class="fas fa-sign-out-alt me-1"></i> Đăng xuất</a>
                        <?php else: ?>
                            <a href="login.php" class="text-white"><i class="fas fa-user me-1"></i> Đăng nhập</a>
                            <a href="register.php" class="text-white ms-3"><i class="fas fa-user-plus me-1"></i> Đăng ký</a>
                        <?php endif; ?>
                    </small>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 shadow-sm">
        <div class="container">
            <a class="navbar-brand" href="index.php">Kids<span>ToyLand</span></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">Trang chủ</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Sản phẩm
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li><a class="dropdown-item" href="#">Đồ chơi cho bé trai</a></li>
                            <li><a class="dropdown-item" href="#">Đồ chơi cho bé gái</a></li>
                            <li><a class="dropdown-item" href="#">Đồ chơi học tập</a></li>
                            <li><a class="dropdown-item" href="#">Đồ chơi vận động</a></li>
                            <li><a class="dropdown-item" href="#">Đồ chơi xếp hình</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Khuyến mãi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="news.php">Tin tức</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="about.php">Về chúng tôi</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#footer">Liên hệ</a>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <form class="search-form me-3" action="search.php" method="GET">
                        <input class="form-control" type="search" name="query" placeholder="Tìm kiếm đồ chơi..." aria-label="Search">
                        <button class="btn btn-primary" type="submit"><i class="fas fa-search"></i></button>
                    </form>
                    <a href="favorites.php" class="btn btn-outline-dark position-relative me-2">
                        <i class="fas fa-heart"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger favorite-badge">
                            <?php echo $favorite_count; ?>
                        </span>
                    </a>
                    <a href="cart.php" class="btn btn-outline-dark position-relative">
                        <i class="fas fa-shopping-cart"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger cart-badge">
                            <?php echo $cart_count; ?>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </nav>
</header>

<!-- MAIN CONTENT -->
<main>
    <!-- Hero Section -->
    <section class="about-hero">
        <div class="container">
            <h1>Về KidsToyLand</h1>
            <p class="lead">Mang niềm vui và sáng tạo đến từng trẻ em</p>
        </div>
    </section>

    <!-- About Section -->
    <section class="py-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 mb-4">
                    <h2 class="fw-bold">Câu chuyện của chúng tôi</h2>
                    <p>KidsToyLand được thành lập với sứ mệnh mang đến những món đồ chơi chất lượng cao, an toàn và giàu tính sáng tạo cho trẻ em khắp Việt Nam. Từ năm 2020, chúng tôi đã không ngừng nỗ lực để cung cấp các sản phẩm giúp trẻ vừa chơi vừa học, phát triển tư duy và kỹ năng một cách toàn diện.</p>
                    <p>Chúng tôi tin rằng mỗi món đồ chơi không chỉ là một sản phẩm, mà còn là một công cụ giúp trẻ khám phá thế giới, nuôi dưỡng trí tưởng tượng và xây dựng những kỷ niệm tuổi thơ đáng nhớ.</p>
                </div>
                <div class="col-lg-6 mb-4">
                    <img src="images/kidtoystore.jpg" class="img-fluid rounded" alt="KidsToyLand Store">
                </div>
            </div>
        </div>
    </section>

    <!-- Mission Section -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Sứ mệnh của chúng tôi</h2>
                <p class="text-muted">Tạo nên những nụ cười và hỗ trợ sự phát triển của trẻ em thông qua đồ chơi.</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="text-center">
                        <i class="fas fa-shield-alt fa-3x mb-3" style="color: var(--primary-color);"></i>
                        <h5>Chất lượng & An toàn</h5>
                        <p>Tất cả sản phẩm đều được kiểm định kỹ lưỡng để đảm bảo an toàn cho trẻ em.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-center">
                        <i class="fas fa-lightbulb fa-3x mb-3" style="color: var(--primary-color);"></i>
                        <h5>Sáng tạo & Học hỏi</h5>
                        <p>Đồ chơi được thiết kế để kích thích tư duy và phát triển kỹ năng của trẻ.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="text-center">
                        <i class="fas fa-heart fa-3x mb-3" style="color: var(--primary-color);"></i>
                        <h5>Niềm vui tuổi thơ</h5>
                        <p>Mang đến những khoảnh khắc vui vẻ và ý nghĩa cho trẻ em và gia đình.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Đội ngũ của chúng tôi</h2>
                <p class="text-muted">Gặp gỡ những người đứng sau KidsToyLand</p>
            </div>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card team-card h-100">
                        <img src="images/nguyenminhanh.jpg" class="card-img-top" alt="Nguyễn Minh Anh">
                        <div class="card-body">
                            <h5 class="card-title">Nguyễn Minh Anh</h5>
                            <p class="card-text">Người sáng lập & CEO</p>
                            <p class="card-text">Minh Anh có hơn 10 năm kinh nghiệm trong ngành đồ chơi trẻ em, với niềm đam mê mang lại niềm vui cho trẻ.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card team-card h-100">
                        <img src="images/tranvanhung.jpg" class="card-img-top" alt="Trần Văn Hùng">
                        <div class="card-body">
                            <h5 class="card-title">Trần Văn Hùng</h5>
                            <p class="card-text">Giám đốc Marketing</p>
                            <p class="card-text">Hùng phụ trách chiến lược quảng bá, giúp KidsToyLand đến gần hơn với các gia đình Việt.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card team-card h-100">
                        <img src="images/lethithanh.jpg" class="card-img-top" alt="Lê Thị Thanh">
                        <div class="card-body">
                            <h5 class="card-title">Lê Thị Thanh</h5>
                            <p class="card-text">Trưởng phòng Sản phẩm</p>
                            <p class="card-text">Thanh đảm bảo mọi sản phẩm đều đạt tiêu chuẩn chất lượng và phù hợp với trẻ em.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Liên hệ với chúng tôi</h2>
                <p class="text-muted">Chúng tôi luôn sẵn sàng hỗ trợ bạn</p>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="contact-info">
                        <p><i class="fas fa-map-marker-alt"></i> 123 Đường Vui Chơi, Quận 1, TP. Hồ Chí Minh</p>
                        <p><i class="fas fa-envelope"></i> info@kidstoy.vn</p>
                        <p><i class="fas fa-phone-alt"></i> 1900 1234</p>
                        <p><i class="fas fa-clock"></i> Giờ làm việc: 8:00 - 17:00, Thứ 2 - Thứ 7</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

<!-- Footer -->
<footer id="footer" class="footer bg-dark">
    <div class="container">
        <div class="row pt-5">
            <div class="col-md-4 col-12 mb-4">
                <h5>KidsToyLand</h5>
                <p>Địa chỉ: 123 Đường Vui Chơi, Quận 1, TP. Hồ Chí Minh</p>
                <p>Email: info@kidstoy.vn</p>
                <p>Điện thoại: 1900 1234</p>
            </div>
            <div class="col-md-4 col-12 mb-4">
                <h5>Liên kết nhanh</h5>
                <ul class="footer-links">
                    <li><a href="index.php">Trang chủ</a></li>
                    <li><a href="#">Sản phẩm</a></li>
                    <li><a href="#">Khuyến mãi</a></li>
                    <li><a href="news.php">Tin tức</a></li>
                    <li><a href="about.php">Về chúng tôi</a></li>
                    <li><a href="#">Liên hệ</a></li>
                </ul>
            </div>
            <div class="col-md-4 col-12 mb-4">
                <h5>Liên hệ</h5>
                <p>Email: support@kidstoyland.com</p>
                <p>Hotline: 0123 456 789</p>
                <div class="social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                </div>
            </div>
        </div>
        <div class="copyright text-center">
            <p>© 2025 KidsToyLand. Tất cả quyền được bảo lưu.</p>
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
ob_end_flush();
?>
